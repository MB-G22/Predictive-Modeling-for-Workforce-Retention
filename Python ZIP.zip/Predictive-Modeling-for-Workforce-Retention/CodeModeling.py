import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, roc_curve, auc, RocCurveDisplay

# 1. LOAD THE CLEANED DATASET
# Using the final dataset generated in Phase 3 to ensure a 'Single Source of Truth'
df = pd.read_csv('TechCorp_Final_Cleaned_Data.csv')

# 2. VALIDATION STRATEGY: 80/20 STRATIFIED SPLIT
X = df.drop('Attrition', axis=1)
y = df['Attrition']

# We use stratify=y to maintain the 16% attrition rate in both sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 3. FIX CLASS IMBALANCE (OVERSAMPLING)
# Training on an imbalanced dataset would lead to poor Recall. 
# We upsample the 'Yes' (1) class in the training set only.
train_data = pd.concat([X_train, y_train], axis=1)
majority = train_data[train_data.Attrition == 0]
minority = train_data[train_data.Attrition == 1]

minority_upsampled = resample(minority, 
                               replace=True,     
                               n_samples=len(majority), 
                               random_state=42)

train_resampled = pd.concat([majority, minority_upsampled])
X_train_final = train_resampled.drop('Attrition', axis=1)
y_train_final = train_resampled['Attrition']

# 4. FEATURE SCALING
# Essential for Logistic Regression to compare coefficients accurately
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_final)
X_test_scaled = scaler.transform(X_test)

# 5. MODEL 1: LOGISTIC REGRESSION (BASELINE)
# Parameters: max_iter=1000 to ensure convergence
lr_model = LogisticRegression(max_iter=1000, random_state=42)
lr_model.fit(X_train_scaled, y_train_final)

# 6. MODEL 2: RANDOM FOREST (CANDIDATE)
# Parameters: 100 trees to capture non-linear interactions
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train_scaled, y_train_final)

# 7. EVALUATION
print("--- Logistic Regression Baseline Results ---")
print(classification_report(y_test, lr_model.predict(X_test_scaled)))

print("\n--- Random Forest Candidate Results ---")
print(classification_report(y_test, rf_model.predict(X_test_scaled)))

# 8. GENERATE FIGURE A1: CONFUSION MATRIX (LOGISTIC REGRESSION)
# This visualizes the True Positives (31) and False Negatives (16) 
y_pred_lr = lr_model.predict(X_test_scaled)
cm = confusion_matrix(y_test, y_pred_lr)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Stay', 'Leave'], 
            yticklabels=['Stay', 'Leave'])
plt.title('Figure A1: Confusion Matrix - Logistic Regression')
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.savefig('Confusion_Matrix.png')
plt.show()

# 9. GENERATE FIGURE A2: ROC CURVE (LOGISTIC REGRESSION)
# Baseline model's ROC curve, evaluated on the scaled test set it was trained on
y_prob_lr = lr_model.predict_proba(X_test_scaled)[:, 1]
fpr_lr, tpr_lr, thresholds_lr = roc_curve(y_test, y_prob_lr)
roc_auc_lr = auc(fpr_lr, tpr_lr)
 
plt.figure(figsize=(8, 6))
plt.plot(fpr_lr, tpr_lr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc_lr:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.title('Figure A2: ROC Curve - Logistic Regression Baseline')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(loc="lower right")
plt.grid(alpha=0.3)
plt.savefig('ROC_Curve_LogisticRegression.png')
plt.show()

# 10. GENERATE FIGURE A3: ROC CURVE (RANDOM FOREST)
# Candidate model's ROC curve, evaluated on the same scaled test set for a fair comparison
y_prob_rf = rf_model.predict_proba(X_test_scaled)[:, 1]
fpr_rf, tpr_rf, thresholds_rf = roc_curve(y_test, y_prob_rf)
roc_auc_rf = auc(fpr_rf, tpr_rf)
 
plt.figure(figsize=(8, 6))
plt.plot(fpr_rf, tpr_rf, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc_rf:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.title('Figure A3: ROC Curve - Random Forest Candidate')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(loc="lower right")
plt.grid(alpha=0.3)
plt.savefig('ROC_Curve_RandomForest.png')
plt.show()